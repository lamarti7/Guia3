/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centralpacientes;

/**
 *
 * @author krkar
 */
public class ListaPacientes {
    private Nodo cabeza;

    public void agregar(Paciente paciente) {
        Nodo nuevo = new Nodo(paciente);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    public Paciente buscar(int id) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.paciente.id == id) {
                return actual.paciente;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public boolean eliminar(int id) {
        if (cabeza == null) return false;

        if (cabeza.paciente.id == id) {
            cabeza = cabeza.siguiente;
            return true;
        }

        Nodo actual = cabeza;
        while (actual.siguiente != null && actual.siguiente.paciente.id != id) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
            return true;
        }

        return false;
    }

    public void mostrar() {
        Nodo actual = cabeza;
        if (actual == null) {
            System.out.println("No hay pacientes registrados.");
            return;
        }
        while (actual != null) {
            System.out.println(actual.paciente);
            actual = actual.siguiente;
        }
    }
}
