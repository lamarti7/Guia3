/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.centralpacientes;

import java.util.Scanner;
/**
 *
 * @author krkar
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ListaPacientes lista = new ListaPacientes();
        int opcion;

        do {
            System.out.println("\n--- Central de Pacientes ---");
            System.out.println("1. Agregar paciente");
            System.out.println("2. Buscar paciente");
            System.out.println("3. Eliminar paciente");
            System.out.println("4. Mostrar todos los pacientes");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Clínica: ");
                    String clinica = sc.nextLine();
                    lista.agregar(new Paciente(id, nombre, edad, clinica));
                    System.out.println("Paciente agregado correctamente.");
                    break;

                case 2:
                    System.out.print("ID del paciente a buscar: ");
                    int idBuscar = sc.nextInt();
                    Paciente p = lista.buscar(idBuscar);
                    if (p != null) {
                        System.out.println("Paciente encontrado: " + p);
                    } else {
                        System.out.println("Paciente no encontrado.");
                    }
                    break;

                case 3:
                    System.out.print("ID del paciente a eliminar: ");
                    int idEliminar = sc.nextInt();
                    if (lista.eliminar(idEliminar)) {
                        System.out.println("Paciente eliminado.");
                    } else {
                        System.out.println("No se encontró el paciente.");
                    }
                    break;

                case 4:
                    System.out.println("\n--- Lista de Pacientes ---");
                    lista.mostrar();
                    break;

                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}
