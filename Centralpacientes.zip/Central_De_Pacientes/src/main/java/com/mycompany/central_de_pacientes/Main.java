/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.central_de_pacientes;

import java.util.Scanner;
/**
 *
 * @author krkar
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ListaPacientes lista = new ListaPacientes();
        int opcion;

        do {
            System.out.println("\n--- Central de Pacientes ---");
            System.out.println("1. Agregar paciente");
            System.out.println("2. Buscar paciente");
            System.out.println("3. Eliminar paciente");
            System.out.println("4. Modificar paciente");
            System.out.println("5. Mostrar todos los pacientes");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    if (lista.buscar(id)!=null) {
                        System.out.println("Ya existe un paciente con el ID" + id);
                        break;
                    }
                    
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Clínica: ");
                    String clinica = sc.nextLine();
                    lista.agregar(new Paciente(id, nombre, edad, clinica));
                    System.out.println("Paciente agregado correctamente.");
                    break;

                case 2:
                    System.out.print("ID del paciente a buscar: ");
                    int idBuscar = sc.nextInt();
                    Paciente p = lista.buscar(idBuscar);
                    if (p != null) {
                        System.out.println("Paciente encontrado: " + p);
                    } else {
                        System.out.println("Paciente no encontrado.");
                    }
                    break;

                case 3:
                    System.out.print("ID del paciente a eliminar: ");
                    int idEliminar = sc.nextInt();
                    if (lista.eliminar(idEliminar)) {
                        System.out.println("Paciente eliminado.");
                    } else {
                        System.out.println("No se encontró el paciente.");
                    }
                    break;

                    
                case 4:
                    System.out.println("ID del paciente a modificar:");
                    int idMod = sc.nextInt();
                    sc.nextLine();
                    Paciente pacienteMod = lista.buscar(idMod);
                    
                    if (pacienteMod == null) {
                        System.out.println("Paciente no encontrado.");
                        break;
                    }
                    
                    int opcionMod;
                    do {
                        System.out.println("\nPaciente actual:");
                        System.out.println(pacienteMod);
                        System.out.println("¿Que desea modificar?");
                        System.out.println("1. ID");
                        System.out.println("2. Nombre");
                        System.out.println("3. Edad");
                        System.out.println("4. Clinica");
                        System.out.println("0. Finalizar modificacion");
                        System.out.println("Opcion:");
                        opcionMod = sc.nextInt();
                        sc.nextLine();
                        
                        switch (opcionMod) {
                            case 1:
                                System.out.println("Nuevo ID:");
                                int nuevoID = sc.nextInt();
                                sc.nextLine();
                                if (lista.buscar(nuevoID)!=null) {
                                    System.out.println("Ya existe un paciente con ese ID. No se actualizo");
                                } else {
                                    pacienteMod.id = nuevoID;
                                    System.out.println("ID actualizado.");
                                }
                                break;
                                
                            case 2:
                                System.out.println("Nuevo nombre:");
                                pacienteMod.nombre = sc.nextLine();
                                System.out.println("Nombre actualizado.");
                                break;
                                
                            case 3:
                                System.out.println("Nueva edad:");
                                pacienteMod.edad = sc.nextInt();
                                sc.nextLine();
                                System.out.println("Edad actualizada.");
                                break;
                                
                            case 4:
                                System.out.println("Nueva clinica:");
                                pacienteMod.clinica = sc.nextLine();
                                System.out.println("Clinica actualizada.");
                                break;
                        
                            case 0:
                                System.out.println("Modificacion finalizada.");
                                break;
                                
                            default:
                                System.out.println("Opcion invalida");
                        }
                    }while (opcionMod!= 0);
                    break;
                    
                case 5:
                    System.out.println("\n--- Lista de Pacientes ---");
                    lista.mostrar();
                    break;   
                    
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}
